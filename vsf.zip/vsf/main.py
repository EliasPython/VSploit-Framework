print('Powered by VSploit Framework')

def vsf_port_scanner():
    import socket

    def port_scanner(ip):
        print(f"Scanning {ip}...")
        for port in range(1, 65535):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((ip, port))
                if result == 0:
                    print(f"Port {port} is open - {get_service_name(port)}")
                sock.close()
            except socket.error:
                print(f"Error scanning port {port}")
                continue

    def get_service_name(port):
        try:
            return socket.getservbyport(port)
        except socket.error:
            return "Unknown service"

    ip = input("Enter IP address: ")
    port_scanner(ip)

def vsf_virus_creator():
	filename = input("Python (.py) File name to create: ")
	
	file = open(filename, "w")
	file.write(
	'''
	# Created with VSf

import tkinter as tk

import random


def create_window():

    window = tk.Toplevel()

    window.geometry("100x100")

    window.overrideredirect(True)

    window.config(bg=random_color())

    window.after(100, window.deiconify)

    window.after(1000, lambda: window.geometry(random_geometry()))

    window.after(1500, lambda: window.config(bg=random_color()))

    window.after(2000, window.destroy)


def random_geometry():

    width = random.randint(0, tk.Tk().winfo_screenwidth())

    height = random.randint(0, tk.Tk().winfo_screenheight())

    x = random.randint(0, tk.Tk().winfo_screenwidth() - width)

    y = random.randint(0, tk.Tk().winfo_screenheight() - height)

    return f"{width}x{height}+{x}+{y}"


def random_color():

    return "#{:06x}".format(random.randint(0, 0xFFFFFF))


for i in range(50):

    create_window()


tk.Tk().mainloop()
	
	'''
	)

vsf_virus_creator()
